##Runtime verification using Dense Timed Automata##

(Implementation in Python of the runtime verification algorithm for timed properties.) 

The main folder contains 2 directories
(1) Source folder which contans the main RVMonitor module and all the properties represented in Uppaal .xml format.
(2)The UppaalLibraries/ directory contains UPPAAL libraries that were used taken from  (http://people.cs.aau.dk/~adavid/python/).
Note that the prototype used was developed and tested on Linux (Ububtu 14, 32-bit version). 

-= INSTALLATION =-

1. Install python. (implementation was performed in Python 2.7)
2. Install the following UPPAAL libraries (that are in directory UppaalLibraries/, or can also be retrieved at http://people.cs.aau.dk/~adavid/python/):
- PyUPPAAL
- UPPAAL DBM
- DBMPyUPPAAL
- PYDBM

-= DESCRIPTION OF THE PROTOTYPE IMPLEMENTATION =-

Below is a description of the source files.

1. ProductTA.py
   This module contains functionality to compute product of two TAs. Note that in the algorithm, we need to compute the product of the automaton defining the input property (psi) and the 
   automaton defining the property to verify (varphi), and two sets of final locations F and F_neg. Method "Product" in this module takes both the TA's as input parameters, 
   and returns the product TA and the two sets of final locations F anf F_neg.      
   
2. RVMonitor.py
   The RVMonitor.py module contains the method "RVmonitor" which is an implementation of the RV monitoring algorithm.  
   It takes the following as input parameters in the following order:
	- Input property psi: UPPAAL model as xml, containing automaton representing the input property psi. (InputTest.xml)
    - Property to verify varphi: UPPAAL model as xml, containing automaton representing the property to verify varphi.
    - InputTrace: A sample input timed word belonging to the input property psi, where each event consists of an action and a delay. 
This module also contains other methods (that are used by the "RVmonitor" method) for checking reachability of a set of locations, and to move in a TA from its current state by consuming a given event etc.   	

Note :- 
-The TA defining properties (in UPPAAL format), labels of accepting locations should start with "Final". The labels cannot be "Final". They can Final1, Final2, etc. 	
-The input property xml file and the property defining xml file should have different clocks.
-The templates in uppaal for both (input property as well as property to verify) should be named as "Property"
-The proeprties and the source code should be in the file.


-= USAGE =-

1. Open command prompt
2. cd to the directory where the source code is present.
3. Open python (Python 2.7)
4. Import the PredictiveRVMonitor module.
5. Invoke the "RVmonitor" method in the RVMonitor module, providing the following arguments in order:
   - Input property 
   - Property to verify
   - Input trace
   
 For example, let "InputTest.xml" be the UPPAAL model containing the TA defining the input property and let "PropertyVerify4.xml" be the UPPAAL model containing the TA defining the property to verify, 
 and let the set of actions Sigma = {p,q,pacing_pulse}. 
 Then the RVmonitor method can be invoked with some test input trace e.g. "('p',89).('q',212).('p',160).('q',750)" as follows: 
 "RVMonitor.RVmonitor("InputTest.xml", "PropertyVerify4.xml", [('p',89),('q',212),('p',160),('q',750)])".  