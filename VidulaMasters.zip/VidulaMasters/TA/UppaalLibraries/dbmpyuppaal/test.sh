#bash
python ./simple_reachibility.py test.xml P.Ok
python ./simple_reachibility.py test.xml P.Bad
