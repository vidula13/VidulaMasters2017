##imports###########################
import SyncRE
import random
import ProgramSim
import FuncLists
####################################
#
#############################################################################
####EditI function ##########################################################
####Input: Automaton phiI, and a state qI of the automaton phiI##############
####Output: Returns all input actions that lead to an accepting state #######
############# in phiI from qI (in one step). ################################
#############################################################################
def editI(phiI, qI):
    '''
    Returns all actions that lead to a location that is not 
        non-accepting given the automaton and the current location
        
    Inputs: phiI - automaton
            qI   - location the automaton is in
    Output: goodAct - list of allowable actions
    '''
    goodAct = []
    for act in phiI.get_S_input():
        for loc in phiI.d_input(qI, act):
            if not loc == phiI.lv:
                if not act in goodAct:
                    goodAct.append(act)
    return goodAct
########################################################################
#
########################################################################
def rand_editI(actions):
    if actions.__len__() >= 0:
        return random.choice(actions)
    else:
        return "NONE"
##########################################################################
#
#########################################################################
def min_editI(actions, event):
    diff_count = []
    if actions.__len__() >= 0:
        for act in actions:
            count = 0
            u=zip(event, act)
            for i,j in u:
                if not i==j:
                    count = count+1
            diff_count.append(count)
        min_indexes = FuncLists.all_indices(min(diff_count), diff_count)
        return actions[random.choice(min_indexes)]
    else:
        return "NONE"
############################################################################

########################################################################
####EditO function. ####################################################
####Input: Automaton phi, a state q of the automaton phi, ##############
####################################and an input action x. #############
####Output: Returns all output actions y that lead to acc state ########
####################### (in one step) in phi from qI upon event (x, y)##
########################################################################
def editO(phi, q, x):
    '''
    Returns all actions that lead to a location that is not 
        non-accepting given an automaton, current location, 
        and the input action
        
    Inputs: phi - automaton
            q   - location the automaton is in
            x   - input action
    Output: goodOutAct - list of allowable actions
    '''
    outAct = []
    goodOutAct = []
    for act in phi.S:
        if not (act[1] in outAct):
            outAct.append(act[1])
    for act in outAct:
        loc = phi.d(q,(x,act), phi.V, do_clks = False)
        if not loc == phi.lv:
            if not act in goodOutAct:
                goodOutAct.append(act)
    return goodOutAct
########################################################################
#
#########################################################################
def rand_editO(actions):
    if actions.__len__() >= 0:
        return random.choice(actions)
    else:
        return "NONE"
##########################################################################
#
#########################################################################
def min_editO(actions, outEvent):
    diff_count = []
    if len(actions) > 0:
        for act in actions:
            count = 0
            u=zip(outEvent, act)
            for i,j in u:
                if not i==j:
                    count = count+1
            diff_count.append(count)
        min_indexes = FuncLists.all_indices(min(diff_count), diff_count)
        return actions[random.choice(min_indexes)]
    else:
        return "NONE"
##########################################################################
#
########################################################################
###Enforcer takes a DFA phi and an input sequence of events#############
####Computes the output sequence incrementally.#########################
########################################################################
def enforcer(phi, phiI, input_trace, output_trace, q, qI):
    ##Initially output is empty.###
    ##Input automaton phiI from input-output automaton phi.##

    ## transformed input xNew, and transformed output yNew initialized to "NONE" ##
    xNew = []
    yNew = []

    ## If from qI upon x, there is a transition in phiI to an accepting state##
    for qI_next in phiI.d_input(qI,input_trace):
        if phiI.F(qI_next):
            xNew = input_trace
            qI = qI_next
            break
        else:
            continue
    ## If from qI upon x, there is NO transition in phiI to an accepting state##
    ###and there is a transition in phiI from qI upon some other action to an accepting state##
    if (xNew == [] and not editI(phiI, qI) == []):
        xNew = min_editI(editI(phiI, qI), input_trace)
        for qi in phiI.d_input(qI,xNew):
            if phiI.F(qi):
                qI = qi
                break
    ###There is no transition in phiI from qI to an accepting state##
    elif (xNew == [] and editI(phiI, qI) == []):
        return ()

    ######Invoke program with transformed input xNew ###########
    ########Process and transform output y returned by program ###############
    y = output_trace
    ## If from q upon (xNew,y), there is a transition in phi to an accepting state ##
    ## phi.d(q,(xNew,y)): all states reachable from q upon (xNew,y) ####
    for q_next in phi.d(q,(xNew,y)):
        if phi.F(q_next):
            yNew = y
            q = q_next
            return xNew, yNew, q, qI
        else:
            continue

    ## If from q upon (xNew,y), there is NO transition in phi to an accepting state ##
    ## but there is a transition from q to an accepting state upon (xNew, y') ######
    if (yNew == [] and not editO(phi, q, xNew) == []):
        yNew = min_editO(editO(phi, q,xNew), y)
        return xNew, yNew, q, qI

    elif (yNew == [] and editO(phi, q, xNew) == []):
        # not enforceable
        return ()
#######################################################################
########################################################################

########################################################################
###Enforcer takes a DTA phi and an input sequence of events#############
####Computes the output sequence incrementally.#########################
########################################################################
def enforcer_dta(phi, phiI, input_trace, output_trace, q, qI):
    ##Initially output is empty.###
    ##Input automaton phiI from input-output automaton phi.##

    print 'phi: = {}'.format(phi.d_all_next(q))
    ## transformed input xNew, and transformed output yNew initialized to [] ##
    xNew = "NONE"
    yNew = "NONE"
    x = input_trace

    # if there is a transition in phiI from qI upon (x,-) to qIi that is not a non-accepting location
    for qI_next in phiI.d_all_next_with_action(qI, (x, phiI.e)):
        if not qI_next == phiI.lv:
            xNew = x
            print "a x ={} xNew ={}".format(x,xNew)
            break

    # there is no transition in phiI from qI upon (x,-) to qIi that is not a non-accepting location
    if xNew == "NONE":
        allowed_inputs = editI(phiI, qI)
        if not allowed_inputs == []:
            ## check
            xNew = min_editI(allowed_inputs, x)
            print "b x ={} xNew ={}".format(x,xNew)
        
        else:
            print('Part A fail')
            ## change to fail gracefully
            # the property is unenforcable
            return () 

    ######Invoke program with transformed input xNew ###########
    ########Process and transform output y returned by program ###############
    y = output_trace

    ## deterministic, therefore should only be one transition
    # if there is a transition in phi from q with action (xNew,y) to a location qi that is not a non-accepting location
    
    for q_next in phi.d_all_next_with_action(q, (xNew, y)):
        print 'a:={}'.format(q_next)
        if not phi.lv == q_next:
            yNew = y
            print "a y ={} yNew ={}".format(y,yNew)
            # clock updates
            phi_run  = phi.d(q,(xNew,yNew), phi.V, do_clks = True)
            phiI_run = phiI.d(qI,(xNew,yNew), phiI.V, do_clks = True)
            #print "a phi_run ={} phiI_run ={}".format(phi_run,phiI_run)
            return xNew, yNew, phi_run[0], phiI_run[0], phi_run[1], phiI_run[1]

        
    # if there is a transition in phi from q upon action (xNew,y') to a location qi that is not a non-accepting location
    allowed_actions = editO(phi, q, xNew)
    if not allowed_actions == []:
        yNew = min_editO(allowed_actions, y)
        print "b y ={} yNew ={}".format(y,yNew)
        ## update to use the transition state outputs as current state
        # clock updates
        phi_run  = phi.d(q,(xNew,yNew), phi.V, do_clks = True)
        phiI_run = phiI.d(qI,(xNew,yNew), phiI.V, do_clks = True)
        return xNew, yNew, phi_run[0], phiI_run[0], phi_run[1], phiI_run[1]
    
    else:
        print('Part B fail')
        ## change to fail gracefully
        # not enforceable
        return ()
#######################################################################
########################################################################