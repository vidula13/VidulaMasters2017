

def delta_avi(q, a, v, do_clks = True):
    '''
    delta_ta is a function that is used as a transition function of our discrete timed automata
    Inputs: q - location you are in,
            a - action you are checking,
            v - set of integer clock variables
            do_clks - boolean to indicate whether to advance the DTA or peek at the transition
            e = empty, used to indicate if something is empty
    Outputs: qj - returns all next locations that match the criteria
    '''
     
    qj = ''
    return_clocks = v
    reset_clocks = [0] * len(v)

    if q == 'q0':
        # Atrial event
        if ((((a[0])[0] == '1') or ((a[1])[0] == '1'))):
            qj = 'q1'
            # reset condition on transition
            if do_clks:
                reset_clocks[0] = 1
                
        else:
            qj = 'q0'
            
    elif q == 'q1':
        if (v[0] > 4):

            # Ventricular event
            if (((a[0])[1] == '1') or ((a[1])[1] == '1')):
                qj = 'q0'

            else:
                qj = 'qn'

        else:
            # Atrial event, unmatched atrial event
            if (((a[0])[0] == '1') or ((a[1])[0] == '1')):
                qj = 'qn'
            
            else:
                # Ventricular event
                if (((a[0])[1] == '1') or ((a[1])[1] == '1')):
                    qj = 'q0'

                else:
                    qj = 'q1'
                         
    elif q == 'qn':
        qj = 'qn'
    
    else:
        print('DEBUG AVI: incorrect format for q = {}, a = {}, v = {}, do_clks = {},'.format(q, a, v, do_clks))

    if do_clks:
        for i in range(len(v)):
            if (reset_clocks[i] == 1):
                return_clocks[i] = 0
            
            else:
                return_clocks[i] += 1
    
    if do_clks:
        return qj, return_clocks

    else:
        return qj
    
    
def generate_avi():
    new_DTA = Automata.DTA(
    #actions#
    generate_actions(bits=4),
    #locations#
    ['q0', 'qv', 'qn'],
    #initial location#
    'q0',
    #accepting locations#
    lambda q: q in ['q0'],    
    #transitions#
    delta_avi,
    #integer clocks#
    [0,],
    #non-accepting location#
    'qn'
    )
    return new_DTA
    
    
def delta_uri(q, a, v, do_clks = True):
    '''
    delta_ta is a function that is used as a transition function of our discrete timed automata
    Inputs: q - location you are in,
            a - action you are checking,
            v - set of integer clock variables
            do_clks - boolean to indicate whether to advance the DTA or peek at the transition
            e = empty, used to indicate if something is empty
    Outputs: qj - returns all next locations that match the criteria
    '''
     
    qj = ''
    return_clocks = v
    reset_clocks = [0] * len(v)
    
    if q == 'q0':
        # Ventricular event
        if ((((a[0])[1] == '1') or ((a[1])[1] == '1'))):
            qj = 'q1'
            # reset condition on transition
            if do_clks:
                reset_clocks[0] = 1
                
        else:
            qj = 'q0'
            
    elif q == 'q1':
        # Ventricular event
        if (((a[0])[1] == '1') or ((a[1])[1] == '1')):

            # if threshold elapsed
            if (v[0] > 9):
                qj = 'q0'
                
            # if under threshold
            else:
                qj = 'qn'
        
        else:
            qj = 'q1'
         
    elif q == 'qn':
        qj = 'qn'
    
    else:
        print('DEBUG URI: incorrect format for q = {}, a = {}, v = {}, do_clks = {},'.format(q, a, v, do_clks))
    
    if do_clks:
        for i in range(len(v)):
            if (reset_clocks[i] == 1):
                return_clocks[i] = 0
            
            else:
                return_clocks[i] += 1
    
    if do_clks:
        return qj, return_clocks

    else:
        return qj
    
    
def generate_uri():
    new_DTA = Automata.DTA(
    #actions#
    generate_actions(bits=4),
    #locations#
    ['q0', 'qv', 'qn'],
    #initial location#
    'q0',
    #accepting locations#
    lambda q: q in ['q0'],    
    #transitions#
    delta_uri,
    #integer clocks#
    [0,],
    #non-accepting location#
    'qn'
    )
    return new_DTA
    