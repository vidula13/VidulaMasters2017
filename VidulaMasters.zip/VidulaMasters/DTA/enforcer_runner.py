def format_bin(value, size):
    if value < 0:   
        value = 2**size + value
    return bin(value)[2:].rjust(size, '0')        
 
 
def generate_actions(bits):
    actions = []
    output_index = bits/2
    
    for i in range(2**bits):
        i_formatted = format_bin(i, bits)
        action = (i_formatted[:output_index], i_formatted[output_index:])
        actions.append(action)
        
    return actions
    
def format_input_trace(H_AS, H_VS):
    input_trace = ''
    if H_AS > SENSING_THRESHOLD:
        input_trace += '1'
    else:
        input_trace += '0'
        
    if H_VS > SENSING_THRESHOLD:
        input_trace += '1'
    else:
        input_trace += '0'
        
    return input_trace
    
    
def format_input_trace_from_user(trace):   
    formatted_trace = ''
    
    for signal in trace:
        formatted_trace += str(signal)
        
    return formatted_trace 

def get_signals(n):
    signals = []
    signal = ''
    
    for i in range(n):
        signal = input('Signal ' + str(i) + ' >>> ')
        signals.append(signal)
    
    return signals

def get_signals_from_user():
    H_AS = input('Heart Atrial Sense>>> ')
    H_VS = input('Heart Ventricular Sense>>> ')
    PM_AP = input('Pacemaker Atrial Pace>>> ')
    PM_VP = input('Pacemaker Ventricular Pace>>> ')
    return (H_AS, H_VS, PM_AP, PM_VP)
 
 
def format_enforcer_status(input_trace, output_trace, enforced_input, enforced_output):
    return 'in: {} out: {} \t\t e_in: {} e_out: {}'.format(input_trace, output_trace, enforced_input, enforced_output)
