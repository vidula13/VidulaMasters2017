import matlab.engine

eng = matlab.engine.start_matlab()
eng.ecgpro(p,qrs)
p = 0
qrs = 0
possible_inputs = ["00", "10", "01", "11"]

if p[0] < qrs[0]:
    x=1
else:
	x=0
MAX_TICKS =  len(p)+ len(qrs)	
while i < MAX_TICKS:	
    if x ==1:
        input_index=2
        x=0;
    else:
        x=1
        input_index=1		
	print ("previnput: {}".possible_inputs[input_index])		