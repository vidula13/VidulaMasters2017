import sys
import random
sys.path.append('../')

import Automata
import SyncRE
import SyncEnforcer
import EnvSimulator
import enforcer_runner
import time
import matlab.engine
eng = matlab.engine.start_matlab()

eng.ecgpro(nargout=0)
p = eng.workspace['p']
qrs = eng.workspace['qrs']




def format_bin(value, size):
    if value < 0:   
        value = 2**size + value
    return bin(value)[2:].rjust(size, '0')        
 
 
def generate_actions(bits):
    actions = []
    output_index = bits/2
    
    for i in range(2**bits):
        i_formatted = format_bin(i, bits)
        action = (i_formatted[:output_index], i_formatted[output_index:])
        actions.append(action)
        
    return actions
    


def delta_aei(q, a, v, do_clks = True):
    '''
    delta_ta is a function that is used as a transition function of our discrete timed automata
    Inputs: q - location you are in,
            a - action you are checking,
            v - set of integer clock variables
            do_clks - boolean to indicate whether to advance the DTA or peek at the transition
            e = empty, used to indicate if something is empty
    Outputs: qj - returns all next locations that match the criteria
    '''
     
    qj = ''
    return_clocks = v
    reset_clocks = [0] * len(v)
    
    if q == 'q0':
        #Atrial and Ventricular event cannot happen simultaneously
        if (((a[0])[1] == '1') and ((a[0])[0] == '1')):
            qj = 'qn'
            
            
        # Ventricular event
        elif ((((a[0])[1] == '1'))):
            qj = 'q1'
            # reset condition on transition
            if do_clks:
                reset_clocks[0] = 1
                
        else:
            qj = 'q0'
            
    elif q == 'q1':
        #Atrial and Ventricular event cannot happen simultaneously
        if (((a[0])[1] == '1') and ((a[0])[0] == '1')):
            qj = 'qn'
            
        # Atrial event
        elif (((a[0])[0] == '1')):

            # if threshold elapsed
            if (v[0] > 2 and v[0]<=5):
                qj = 'q0'
                
            # if under threshold
            else:
                qj = 'qn'
        
        else:
            qj = 'q1'
         
    elif q == 'qn':
        qj = 'qn'
        
    
    else:
        print('DEBUG AEI: incorrect format for q = {}, a = {}, v = {}, do_clks = {},'.format(q, a, v, do_clks))
    
    if do_clks:
        for i in range(len(v)):
            if (reset_clocks[i] == 1):
                return_clocks[i] = 0
            
            else:
                return_clocks[i] += 1
    
    if do_clks:
        return qj, return_clocks

    else:
        return qj
    
    
def generate_aei():
    new_DTA = Automata.DTA(
    #actions#
    generate_actions(bits=4),
    #locations#
    ['q0', 'qv', 'qn'],
    #initial location#
    'q0',
    #accepting locations#
    lambda q: q in ['q0'],    
    #transitions#
    delta_aei,
    #integer clocks#
    [0,],
    #non-accepting location#
    'qn'
    )
    return new_DTA
    



def main():
   
    i = 0
    

    continue_running = True
    
    input_trace = ''
    output_trace = ''
    
    print "Tick by tick execution of Property3"


    '''
    Example trace
    01 (state q0 --> state q1)
    00 (state q1)
    10 (state q1 --> state q0, clock reset to 0)
   
    '''
    
    possible_inputs = ["00", "10", "01", "11"]
    

    phi = generate_aei()
    phi.q = phi.q0
    MAX_TICKS = 6

    while i < MAX_TICKS:
        print 'Tick: ' + str(i+1) + '  +++++++++++++++++++++++++++++++++++++++='


        output_trace = "00"
        
        input_index = random.randint(0, 3)
   
        (phi.q, phi.V) =  phi.d(phi.q, (possible_inputs[input_index], output_trace), phi.V, True)


        print("Input Signal:{}".format(possible_inputs[input_index]))
        
        
        print("Current location: {} PrevInput: {}  Tick: {} Clocks: {}".format(phi.q, possible_inputs[input_index],   i, phi.V))
        
        if phi.q == 'qn':
            print("ALARM!! Property violation")
        
        i += 1
        
        t1 = time.clock()
        t2 = time.clock()
        print "total time is.." + str(t2-t1)
        
        
if __name__ == '__main__':
    main()
