﻿##Runtime verification using Dense Timed Automata##

(Implementation done in Python 2.7 of the runtime verification algorithm for timed properties.)
- Here we are calling Matlab script in Python.
- Basically, using matlab variables as inputs to python script.

Installations
- Matlab R2014b or higher version. (interfacing of matlab and python was introduced in Matlab R2014b version)
- Python 2.7

Getting started with interfacing
-Here is a link which shows how to install Matlab API for python
https://in.mathworks.com/help/matlab/matlab_external/install-the-matlab-engine-for-python.html

Execute these commands in the command prompt. (Run command prompt as administrator otherwise it may not get installed)
-On Windows systems —
cd "matlabroot\extern\engines\python"
python setup.py install

-On Mac or Linux systems —
cd "matlabroot/extern/engines/python"
python setup.py install

where "matlabroot" is the path to the MATLAB folder.

Copy the soucre folder in "matlabroot\extern\engines\python"
Note- matlab script, python script and the .mat file should be in the same folder as mentioned above.

##USAGE##
1. Open command prompt (as administrator)
2. cd to "matlabroot\extern\engines\python"
3. Run the script by giving the command "python Property(2/3/4/5).py" (If you have both Python 2.7 as well as Python 3.x on your system give "py -2 Property(2/3/4/5).py")