clear all; clc; close all;
load pacing

Fs = 128000;

t = 1/Fs:1/Fs:length(ECG)/Fs; % seconds
plot(t,ECG)
title('ECG signal with pacing artifacts')
xlabel('Seconds');
ylabel('Voltage(mV)')
legend('DDD ECG Signal')
grid on

%Savitzky-Golay filtering is used to remove noise in the signal.
ECG = sgolayfilt(ECG,7,21);

%R peaks detection
[~,locs_Rwave] = findpeaks(ECG,'MinPeakHeight',1.5,...
                                    'MinPeakDistance',100000);
Rwaves = locs_Rwave/Fs

[~,min_locs] = findpeaks(-ECG,'MinPeakDistance',10000);

locs_Swave = min_locs(ECG(min_locs)>-0.315 & ECG(min_locs)<-0.25);
qrs = locs_Swave/Fs

[~,locs_pulse] = findpeaks(-ECG,'MinPeakHeight',0.4,...
                                    'MinPeakDistance',10000);
                                
pacing_pulse = locs_pulse/Fs

[~,min_locs2] = findpeaks(ECG,'MinPeakDistance',7000);
locs_Pwave = min_locs2(ECG(min_locs2)>0.15 & ECG(min_locs2)<0.2);
p = locs_Pwave/128000

[~,min_locs3] = findpeaks(ECG,'MinPeakDistance',7000);
locs_Twave = min_locs3(ECG(min_locs2)>0.34 & ECG(min_locs2)<0.4);
Twaves = locs_Twave/128000

figure
hold on
plot(t,ECG)
plot(Rwaves,ECG(locs_Rwave),'rv','MarkerFaceColor','r');
plot(qrs,ECG(locs_Swave),'rs','MarkerFaceColor','g');
plot(pacing_pulse,ECG(locs_pulse),'rv','MarkerFaceColor','r');
plot(p,ECG(locs_Pwave),'rv','MarkerFaceColor','b');
plot(Twaves,ECG(locs_Twave),'rv','MarkerFaceColor','y');
axis([0 10 -1 2])
grid on
title('Thresholding Peaks in Signal')
legend('ECG Signal','R-waves','S-waves','Pacing pulses','P-waves','T-waves')
xlabel('Seconds')
ylabel('Voltage(mV)')

beat_count = length(Rwaves);
Fs = 128000;
N = length(ECG)/Fs
dur_in_min = N/60
BPM = beat_count/dur_in_min




                                                                
