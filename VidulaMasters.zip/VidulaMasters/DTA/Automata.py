#####Imports####################
from itertools import  izip
from copy import deepcopy
###############################


##function to sort a tuple###
def ts(x):
    return tuple(sorted(x))

############################################################
############################################################

class DFA:
    def __init__(self, S, Q, q0, F, d, e = ('.l',)):
        self.alphabet = S
        self.states = Q
        self.initial_state = q0
        self.current_state = q0
        self.accepting_func = F
        self.transition_func = d
        self.empty_word = e # empty word

        self.reset()
        
    def complement(self):
        
        newSetF = set()
        
        for q in self.states:
            if not self.accepting_func(q):
                newSetF.add(q)
                
        self.accepting_func = lambda q: q in newSetF

    def isEmpty(self):
        
        visited = set()
        
        def dfs(node):
            visited.add(node)
            for a in self.alphabet:
                q = self.transition_func(node, a)
                if q and q not in visited:
                    dfs(q)
                    
        dfs(self.initial_state)
        
        return all(not self.accepting_func(q) for q in visited)

    def show(self):
       
        print '=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-='
        print 'alphabet:', sorted(self.alphabet)
        print '\nstates:', sorted(self.states)
        print '\ninit:', self.initial_state
        print '\nfinal:'
        for s in sorted(self.states):
            if self.accepting_func(s):
                print s
        print '\ntransitions:'
        for s in sorted(self.states):
            for a in self.alphabet:
                self.reset(s)
                self.step(a)
                print (s, a), '->', self.current_state
            print
        print '=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-='
        
        self.graph()

    def graph(self):
        
        print '+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+'
        print
        for i, q in enumerate(sorted(self.states)):
            fill = list('999')
            if q == self.initial_state:
                fill[1] = 'f'
            if self.accepting_func(q):
                fill[0] = 'f'
            if fill == list('999'):
                fill = list('fff')
            print '%s [label="%s" style="fill: #%s"];' % (i, q, ''.join(fill))
        print
        sQ = sorted(self.states)
        for i, s in enumerate(sorted(self.states)):
            for a in self.alphabet:
                self.reset(s)
                self.step(a)
                print(sQ)
                print '%s -> %s [labelType = "html" label="<div style=\'width:20px; height:20px; background-color:white; z-index:100; border: 1.5px solid black; text-align: center; border-radius: 5px;\'>%s</div>" lineInterpolate="basis"]' % (i, sQ.index(self.current_state), a)
            print
        print
        print '+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+'

    def reset(self, q = None):
        
        q = q or self.initial_state
        
        self.current_state = q

    def step1(self, a):
        if a and a not in self.empty_word:
            self.current_state = self.transition_func(self.current_state, a)
            return self.current_state
            
    def makeInit(self, q):
       
        self.initial_state = q
                    
    def step(self, a):
        
        if a and a not in self.empty_word:
            self.current_state = self.transition_func(self.current_state, a)

    def isInAcceptingState(self):
        return self.accepting_func(self.current_state)

    def accepts(self, w):
               
        if not w or w == self.empty_word:
            return self.accepting_func(self.initial_state)
            
        
        if w == ('.d',): 
            return False
        
        q = self.current_state
        
        self.reset()

        for a in w:
            self.step(a)
            
        ret = self.isInAcceptingState()
        
        self.reset(q)

        return ret

############################################################
############################################################


############################################################
############################################################

class DFAProduct:

    def __init__(self, dfas, outFun = None, e = ('.l',)):
        
        outFun = outFun or str
        
        self.empty_word = e
        
        self.alphabet = dfas[0].S
        
        assert all(self.alphabet == dfa.S for dfa in dfas)
        
        self.initial_state = tuple(dfa.q0 for dfa in dfas)
        self.current_state = self.initial_state
        
        def d(q, a):
            return tuple(dfa.d(qi, a) for qi, dfa in izip(q, dfas))
        
        self.transition_func = d

        def g(q):
            return outFun(tuple({False : 0, True : 1}[dfa.F(qi)] for qi, dfa in izip(q, dfas)))

        self.g = g
        
        self.reset()
        
        # perform a DFS in order to identify Q (reachable product states)!
        visited = set()
        def dfs(node):
            visited.add(node)
            for a in self.alphabet:
                q = self.transition_func(node, a)
                if q and q not in visited:
                    dfs(q)

        dfs(self.initial_state)

        self.states = visited

    def getDFA(self):
        
        deltaDict = {}
        
        for q in self.states:
            for a in self.alphabet:
                deltaDict[(q, a)] = self.transition_func(q, a)
        
        finalSet = set()
        
        for q in self.states:
            if self.g(q): # self.g must return True / False
                finalSet.add(q)
        
        return DFA( self.alphabet,
                    self.states,
                    self.initial_state,
                    lambda q: q in finalSet, 
                    lambda q, a: deltaDict[(q, a)])
        
    def show(self):
       
        print '=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-='
        print 'alphabet:', sorted(self.alphabet)
        print '\nstates:', sorted(self.states)
        print '\ninit:', self.initial_state
        print '\noutput:'
        for so in sorted(zip(self.states, map(self.g, self.states)), key = lambda (q, g): (g, q)):
            print so
        print '\ntransitions:'
        for s in sorted(self.states):
            for a in self.alphabet:
                self.reset(s)
                self.step(a)
                print (s, a), '->', self.current_state
            print
        print '=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-='
        
        self.graph()
        
    def graph(self):
        
        print '+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+'
        print
        for i, q in enumerate(sorted(self.states)):
            fill = list('999')
            if q == self.initial_state:
                fill[1] = 'f'
            if self.g(q):
                fill[0] = 'f'
            if fill == list('999'):
                fill = list('fff')
            print '%s [label="%s" style="fill: #%s"];' % (i, '(' + ', '.join(q) + ')', ''.join(fill))
        print
        sQ = sorted(self.states)
        for i, s in enumerate(sorted(self.states)):
            for a in self.alphabet:
                self.reset(s)
                self.step(a)
                print '%s -> %s [labelType = "html" label="<div style=\'width:20px; height:20px; background-color:white; z-index:100; border: 1.5px solid black; text-align: center; border-radius: 5px;\'>%s</div>" lineInterpolate="basis"]' % (i, sQ.index(self.current_state), a)
            print
        print
        print '+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+'
        
    def reset(self, q = None):
        
        q = q or self.initial_state
        
        self.current_state = q
        self.o = self.g(q)

    def step(self, a):
        
        if a and a != self.empty_word:
            self.current_state = self.transition_func(self.current_state, a)
            self.o = self.g(self.current_state)
             
    def transduce(self, w):
        
        if w == self.empty_word:
            return self.o
        
        q = self.current_state
        
        self.reset()
               
        ret = [self.o]
        
        for a in w:
            self.step(a)
            ret.append(self.o)
            
        self.reset(q)

        return tuple(ret)

############################################################
############################################################


############################################################
############################################################

class NFA:

    def __init__(self, S, Q, q0, F, d, e = ('.l',)):
        self.S = S
        self.Q = Q
        self.q0 = q0
        self.q = ts({q0})
        self.F = F
        self.d = d
        self.e = e # empty word
        
        
        #temp
        self.V = {}
        self.reset()
        
    def toDFA(self):
        
        statesMet = {}
        statesMet2 = {ts({self.initial_state})}
        
        while statesMet != statesMet2:
        
            statesMet = deepcopy(statesMet2)
            for q in statesMet:
                for a in self.alphabet:
                    self.reset(q)
                    self.step(a)
                    statesMet2.add(self.current_state)
        
        deltaDict = {}
        for i, s in enumerate(sorted(statesMet)):
            for a in self.alphabet:
                self.reset(s)
                self.step(a)
                deltaDict[(s, a)] = self.current_state
            fill = list('999')
            if s == ts({self.initial_state}):
                fill[1] = 'f'
            if any(self.accepting_func(q) for q in s):
                fill[0] = 'f'
            if fill == list('999'):
                fill = list('fff')
            print '%s [label="%s" style="fill: #%s"];' % (i, '{' + ', '.join(s) + '}', ''.join(fill))
                
        sQ = sorted(statesMet)
        for i, ((s1, a), s2) in enumerate(sorted(deltaDict.items())):
            print '%s -> %s [labelType = "html" label="<div style=\'width:20px; height:20px; background-color:white; z-index:100; border: 1.5px solid black; text-align: center; border-radius: 5px;\'>%s</div>" lineInterpolate="basis"]' % (sQ.index(s1), sQ.index(s2), a)
            
        print 'DFA transitions:'
        counter = 0
        for i, (k, v) in enumerate(sorted(deltaDict.items())):
            print k, '->', v
            counter += 1
            if counter % 2 == 0:
                print

    def reset(self, q = None):
        
        q = q or ts({self.initial_state})
        
        self.current_state = q

    def step(self, a):
        if a and a not in self.empty_word:
            nextState = set()
            for s1 in self.q:
                for s2 in self.d(s1, a, do_clks = False):
                    nextState.add(s2)
            self.current_state = ts(nextState)

    def isInAcceptingState(self):
        return any(self.accepting_func(s) for s in self.current_state)

    def accepts(self, w):
        if not w or w == self.empty_word:
            return self.accepting_func(self.initial_state)
            
        if w == ('.d',): 
            return False
        
        q = self.current_state
        
        self.reset()

        for a in w:
            self.step(a)
            
        ret = self.isInAcceptingState()
        
        self.reset(q)

        return ret
       
   # temp here
    def d_input(self, action_input):
        action_list = [action for action in self.S if action[0] == action_input]
        
        return_val = []
        for action in action_list:
            for qx in self.q:
                qi = self.d(qx, action, self.V, do_clks = False)
                if not (qi[0] in return_val):
                    return_val.append(qi[0])
        return return_val

############################################################
############################################################

def includesLang(dfa1, dfa2):
    
    # return True if L(dfa1) includes L(dfa2)
    # and False otherwise
    
    dfa1c = deepcopy(dfa1)
    dfa1c.complement()
    
    diff = DFAProduct([dfa1c, dfa2], lambda (o1, o2) : o1 and o2).getDFA()
    
    return diff.isEmpty()

##################################################################################
##################################################################################


class DTA:

    def __init__(self, S, Q, q0, F, d, V = {}, lv = {}, e = ('.l',)):
        self.S = S
        self.Q = Q
        self.q0 = q0
        self.q = ts({q0})
        self.F = F
        self.d = d
        self.V = V
        
        if not (lv == e):
            self.lv = lv
        else:
            self.lv = e
        self.e = e # empty word

        self.reset()
    
    # not used
    def d_all_next(self, q):
        '''
        Gets all locations qi that have a transition from q to qi upon any action in this DTA.
        Inputs: q - location you want the next locations from
        Ouputs: return_val - all states that can be immediately reached from this location 
        '''
        
        return_val = []
        for action in self.S:
            qi = self.d(q, action, self.V, do_clks = False)
            if not qi in return_val:
                return_val.append(qi)
        return return_val
        
        
    def d_all_accepting_next(self, q):
        '''
        Gets all accepting locations qi that have a transition from q to qi upon any action in this DTA.
        Inputs: q - location you want the next locations from
        Ouputs: return_val - all states that can be immediately reached from this location 
        '''
        
        return_val = []
        for action in self.S:
            qi = self.d(q, action, self.V, do_clks = False)
            if not qi in return_val:
                if self.F(qi):
                    return_val.append(qi)
                    
        return return_val
        
        
    def d_all_next_with_action(self, q, a):
        '''
        Gets all locations qi that have a transition from q to qi upon action a in this DTA.
        Inputs: q - location you want the next locations from
                a - action that must be on the transition to the next location
        Ouputs: return_val - all states that have action a, as a transition to them from location q
        '''
        
        return_val = []
        
        # if a[1] is empty, we are doing input enforcement
        if (a[1] == self.e):
            # generates all possible actions given an input action
            # eg. if action_input = 00, it generates [('00','00'),('00','01'),..('00','11')]
            action_list = [action for action in self.S if action[0] == a[0]]
            
            for action in action_list:
                qi = self.d(q, action, self.V, do_clks = False)
                if not qi in return_val:
                    return_val.append(qi)
                    
        # if the action is for bidirectional enforcement
        else:
            qi = self.d(q, a, self.V, do_clks = False)
            return_val.append(qi)
            
        return return_val
        
        
    def d_all_accepting_next_with_action(self, q, a):
        '''
        Gets all accepting locations qi that have a transition from q to qi upon action a in this DTA.
        Inputs: q - location you want the next locations from
                a - action that must be on the transition to the next location
        Ouputs: return_val - all states that can be immediately reached from this location 
        '''
        
        return_val = []
        
        # if a[1] is empty, we are doing input enforcement
        if (a[1] == self.e):
            # generates all possible actions given an input action
            # eg. if action_input = 00, it generates [('00','00'),('00','01'),..('00','11')]
            action_list = [action for action in self.S if action[0] == a[0]]
            
            for action in action_list:
                qi = self.d(q, action, self.V, do_clks = False)
                if not qi in return_val:
                    if self.F(qi):    
                        return_val.append(qi)
                    
        # if the action is for bidirectional enforcement
        else:
            qi = self.d(q, a, self.V, do_clks = False)
            if self.F(qi):    
                return_val.append(qi)
            
        return return_val

        
    def resetClk(self, clk):
        self.V[clk] = 0
    
    
    def reset(self, q = None):
        for clock in self.V:
            self.resetClk(clock)
    
        q = q or ts({self.q0})
        self.q = q
    
           
    def step(self, a):
        if a and a not in self.e:
            for clock in self.V:
                self.V[clock] += 1
            
            nextState = set()
            for s1 in self.q:
                for s2 in self.d(s1, a, self.V, do_clks = True):
                    nextState.add(s2[0])
            self.q = ts(nextState)

            
    def isInAcceptingState(self):
        return any(self.F(s) for s in self.q)

        
    def accepts(self, w):
        if not w or w == self.e:
            return self.F(self.q0)
            
        if w == ('.d',): 
            return False
        
        q = self.q
        
        self.reset()

        for a in w:
            self.step(a)
            
        ret = self.isInAcceptingState()
        
        self.reset(q)

        return ret
        
        
    def get_S_input(self):
        inAlphabet= []
    
        for action in self.S:
            if not (action[0] in inAlphabet):
                inAlphabet.append(action[0])
        return inAlphabet
        
    
    def d_input(self, q, action_input):
        # generates all possible actions given an input action
        # eg. if action_input = 00, it generates [('00','00'),('00','01'),..('00','11')]
        action_list = [action for action in self.S if action[0] == action_input]
        
        return_val = []
        for action in action_list:
            qi = self.d(q, action, self.V, do_clks = False)
            if not qi in return_val:
                return_val.append(qi)
        return return_val
    
    def show(self):
        print(self.S)
        print(self.Q)
        print(self.q0)
        print(self.q)
        print(self.F)
        print(self.d)
        print(self.V)