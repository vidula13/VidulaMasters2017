##ECG Signal Processing##

##USAGE##
1. Open the matlab script in the editor.
2. Run the script.

Note - You can use this code for any .mat files of ECG signals, with little modification in the ranges of the "findpeaks" function.
     - Open any database of ECG signals (.dat files)
     - Save them as name.mat files in a writable folder. (% do not save the mat files in the MATLAB folder%)
     - Try loading the mat file in the matlab command window (load name.mat)
     - Now, you can use this file instead of the one used in the code.
     - The pacing.mat file used in this script is provided.	 