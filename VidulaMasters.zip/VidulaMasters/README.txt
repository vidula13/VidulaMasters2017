The main folder contains 3 directories
1. ECG_processing contains matlab script and mat file.
2. TA folder contains the implememntation of runtime verification algorithm represented in Dense Timed Automata.
3. DTA folder contains the implememntation of runtime verification algorithm represented in Discrete Timed Automata.
4. vidula_712746152_789.pdf is the reserach project report
Note - All the properties verified are same as mentioned in the report. The numbering of the properties is also as given in the report. 
     - Please refer the report before running the codes for better understanding of the implementation.